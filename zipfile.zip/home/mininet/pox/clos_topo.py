#!/usr/bin/python
from mininet.topo import Topo
from mininet.net import Mininet
from mininet.cli import CLI
from mininet.node import CPULimitedHost
from mininet.link import TCLink
from mininet.util import irange,dumpNodeConnections
from mininet.log import setLogLevel
from mininet.node import RemoteController

import argparse
import sys
import time
import math

class ClosTopo(Topo):

    def __init__(self, fanout, cores, **opts):
        # Initialize topology and default options
        Topo.__init__(self, **opts)
       
        "Set up Core and Aggregate level, Connection Core - Aggregation level"
        Aggregations = []
        Cores = []
        for i in range(3,7):
            Aggregations.append(self.addSwitch('a' + str(i)))
        for i in range(1,3):
            Cores.append(self.addSwitch('c' + str(i)))
        #---------------------------------------------------------
        for i in range(0,4):
            for j in range(0,2):            
                self.addLink(Aggregations[i],Cores[j])

        "Set up Edge level, Connection Aggregation - Edge level "
        Edges = []  
        for i in range(7,15):
            Edges.append(self.addSwitch('e' + str(i)))
        #---------------------------------------------------------
        for i in range(0,8):
            for j in range(0,4):
                self.addLink(Edges[i],Aggregations[j])
            
        "Set up Host level, Connection Edge - Host level "
        Hosts = []            
        for i in range(1,17):
            Hosts.append(self.addHost('h' + str(i)))
        #---------------------------------------------------------
        for i in range(0,8):
            self.addLink( Hosts[ i * 2 ] , Edges[ i ] )
            self.addLink( Hosts[ i * 2 + 1 ] , Edges[ i ] )            
            
def setup_clos_topo(fanout=2, cores=1):
    "Create and test a simple clos network"
    assert(fanout>0)
    assert(cores>0)
    topo = ClosTopo(fanout, cores)
    net = Mininet(topo=topo, controller=lambda name: RemoteController('c0', "127.0.0.1"), autoSetMacs=True, link=TCLink)
    net.start()
    time.sleep(20) #wait 20 sec for routing to converge
    net.pingAll()  #test all to all ping and learn the ARP info over this process
    CLI(net)       #invoke the mininet CLI to test your own commands
    net.stop()     #stop the emulation (in practice Ctrl-C from the CLI 
                   #and then sudo mn -c will be performed by programmer)

    
def main(argv):
    parser = argparse.ArgumentParser(description="Parse input information for mininet Clos network")
    parser.add_argument('--num_of_core_switches', '-c', dest='cores', type=int, help='number of core switches')
    parser.add_argument('--fanout', '-f', dest='fanout', type=int, help='network fanout')
    args = parser.parse_args(argv)
    setLogLevel('info')
    setup_clos_topo(args.fanout, args.cores)


if __name__ == '__main__':
    main(sys.argv[1:])

