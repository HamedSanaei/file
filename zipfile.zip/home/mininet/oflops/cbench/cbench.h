#ifndef CBENCH_H
#define CBENCH_H

#ifndef BUFLEN
#define BUFLEN 65536
#endif

#endif
