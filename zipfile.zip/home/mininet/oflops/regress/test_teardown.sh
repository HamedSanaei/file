#!/bin/sh

killall switch
rmmod veth
